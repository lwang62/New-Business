export const environment = {
  production: true,
  baseApiUrl: '/new-business/status-tracker/api'
};
