export const environment = {
  production: false,
  baseApiUrl: '/new-business/status-tracker/api'
};
