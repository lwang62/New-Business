import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-type',
  templateUrl: './display-type.component.html',
  styleUrls: ['./display-type.component.scss']
})
export class DisplayTypeComponent implements OnInit {
  selected = 'table';

  constructor() { }

  ngOnInit() {
  }

  changeDisplayType(type: string) {
    this.selected = type;
  }
}
