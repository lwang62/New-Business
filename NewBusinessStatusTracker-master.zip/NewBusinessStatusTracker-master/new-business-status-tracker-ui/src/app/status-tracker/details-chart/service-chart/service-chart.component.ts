import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ChartType } from 'chart.js';
import { Observable, Subscription } from 'rxjs';
import { NewBusinessStatus } from '@models/new-business-status';
import { StatusService } from '@services/data/status.service';
import { LoadingService } from '@services/common/loading.service';

@Component({
  selector: 'app-service-chart',
  templateUrl: './service-chart.component.html',
  styleUrls: ['./service-chart.component.scss']
})
export class ServiceChartComponent implements OnInit, OnDestroy {

  @Input() serviceName: string;
  @Input() dataServiceName: string;
  statuses: string[];

  statusesObservable: Observable<NewBusinessStatus[]>;
  statusesSubscription: Subscription;
  nbStatuses: NewBusinessStatus[];

  chartType: ChartType = 'pie';

  chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    elements: {
      arc: {
          borderWidth: 0
      }
    },
    legend: {
      display: false,
    }
  };

  chartData = [];
  chartLabels = ['Completed', 'Pending', 'Failed'];
  chartColors = [{backgroundColor: ['rgb(28, 197, 78)', 'rgb(255, 194, 55)', 'rgb(201, 20, 50)']}];

  constructor(private statusService: StatusService,
              private loadingService: LoadingService) {
    this.statusesObservable = this.statusService.nbStatuses$;
  }

  ngOnInit() {
    // Subscribe to observable and render table
    this.statusesSubscription = this.statusesObservable.subscribe(
      (statuses) => {
        if (statuses != null) {
          this.nbStatuses = statuses;
          this.buildChartByStatus();
          this.loadingService.stopLoading();
        }
      }
    );
  }

  buildChartByStatus() {
    let completed = 0;
    let pending = 0;
    let failed = 0;

    this.statuses = this.nbStatuses.map(arr => arr[`${this.dataServiceName}`].status );

    // Get number of statuses
    this.statuses.forEach((status) => {
      switch (status) {
        case 'completed': {
          completed++;
          break;
        }
        case 'pending': {
          pending++;
          break;
        }
        case 'failed': {
          failed++;
          break;
        }
      }
    });
    this.chartData = [
      { data: [completed, pending, failed] }
    ];
  }

  // Unsubscribe
  ngOnDestroy(): void {
    this.statusesSubscription.unsubscribe();
  }

}
