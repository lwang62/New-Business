import { Component, OnInit, OnDestroy } from '@angular/core';
import { NewBusinessStatus } from '@models/new-business-status';
import { ChartType } from 'chart.js';
import { Observable, Subscription } from 'rxjs';
import { StatusService } from '@services/data/status.service';
import { LoadingService } from '@services/common/loading.service';

@Component({
  selector: 'app-overall-status-chart',
  templateUrl: './overall-status-chart.component.html',
  styleUrls: ['./overall-status-chart.component.scss']
})
export class OverallStatusChartComponent implements OnInit, OnDestroy {

  overallStatuses: string[];

  statusesObservable: Observable<NewBusinessStatus[]>;
  statusesSubscription: Subscription;
  nbStatuses: NewBusinessStatus[];

  chartType: ChartType = 'horizontalBar';

  chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
        display: false,
    },
    scales: {
      yAxes: [{
        ticks: {
          fontSize: 18,
          fontColor: '#737373'
        }
      }],
      xAxes: [{
        ticks: {
          fontSize: 18,
          fontColor: '#737373',
          beginAtZero: true,
          userCallback: (label) => {
            // when the floored value is the same as the value we have a whole number
            if (Math.floor(label) === label) {
                return label;
            }
          }
        }
      }]
    }
  };

  chartData = [];
  chartLabels = ['Completed', 'Pending', 'Failed'];
  chartColors = [{backgroundColor: ['rgb(28, 197, 78)', 'rgb(255, 194, 55)', 'rgb(201, 20, 50)']}];

  constructor(private statusService: StatusService,
              private loadingService: LoadingService) {
    this.statusesObservable = this.statusService.nbStatuses$;
  }

  ngOnInit() {
    // Subscribe to observable and render table
    this.statusesSubscription = this.statusesObservable.subscribe(
      (statuses) => {
        if (statuses != null) {
          this.nbStatuses = statuses;
          this.buildChartByOverallStatus();
          this.loadingService.stopLoading();
        }
      }
    );
  }

  buildChartByOverallStatus() {
    let completed = 0;
    let pending = 0;
    let failed = 0;

    this.overallStatuses = this.nbStatuses.map(arr => arr.status);

    // Get number of statuses
    this.overallStatuses.forEach((status) => {
      switch (status) {
        case 'completed': {
          completed++;
          break;
        }
        case 'pending': {
          pending++;
          break;
        }
        case 'failed': {
          failed++;
          break;
        }
      }
    });
    this.chartData = [
      { data: [completed, pending, failed] }
    ];
  }

  // Unsubscribe
  ngOnDestroy(): void {
    this.statusesSubscription.unsubscribe();
  }

}
