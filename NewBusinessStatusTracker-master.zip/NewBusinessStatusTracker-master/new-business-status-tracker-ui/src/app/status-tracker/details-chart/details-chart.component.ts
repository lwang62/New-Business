import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-details-chart',
  templateUrl: './details-chart.component.html',
  styleUrls: ['./details-chart.component.scss']
})
export class DetailsChartComponent implements OnInit {
  ngOnInit() {
  }
}
