import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject, Observable, Subscription } from 'rxjs';
import { LoadingService } from '@app/services/common/loading.service';
import { DataTableDirective } from 'angular-datatables';
import { NewBusinessStatus } from '@models/new-business-status';
import { StatusService } from '@services/data/status.service';
import * as $ from 'jquery';
import { trigger, transition, style, animate, keyframes, state } from '@angular/animations';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
  // animations: [
  //   trigger('modalRemoveTrigger', [
  //     transition(':leave', [
  //       transition('void => *', [
  //         style({ transform: 'scale3d(.3, .3, .3)' }),
  //         animate(100)
  //       ]),
  //       transition('* => void', [
  //         animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
  //       ])
  //     ])
  //   ]),
  // ]
})
export class DataTableComponent implements OnInit, OnDestroy {
  // Datatables variables
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  dtInitialized = false;

  statuses$: Observable<NewBusinessStatus[]>;
  statusesSubscription: Subscription;

  selectedNbStatus: NewBusinessStatus;
  modalOpen = false;

  constructor(private loadingService: LoadingService,
              private statusService: StatusService) {
    // Set observable to service Behavior Subject observable
    this.statuses$ = this.statusService.nbStatuses$;
  }

  ngOnInit() {
    // Start Loader
    this.loadingService.startLoading();

    // Subscribe to statuses Observable
    this.statusesSubscription = this.statuses$.subscribe(
      (statuses) => {
        if (statuses != null) {
          this.renderTable();
        }
      }
    );

    // Set datatable options
    this.dtOptions = {
      pagingType: 'simple_numbers',
      pageLength: 10,
      scrollY: '55vh',
      scrollCollapse: true,
      lengthChange: false,
      searching: false,
      language: {
        info: 'Showing page _PAGE_ of _PAGES_',
        infoEmpty: 'No records found',
        zeroRecords: 'No records found',
        paginate: {
          next: '&#8594;', // '→'
          previous: '&#8592;', // '←'
          first: '',
          last: ''
        }
      },
      responsive: true,
      order: [[2, 'desc']],
      initComplete: () => {
        this.loadingService.stopLoading();
        this.dtInitialized = true;
      }
    };

  }

  // Open modal window
  openModal(nbStatus: NewBusinessStatus) {
    this.modalOpen = true;
    this.selectedNbStatus = nbStatus;
  }

  // Get color for different statuses
  getStatusColor(status: string) {
    switch (status) {
      case 'failed': {
        return '#c91432';
      }
      case 'pending': {
        return '#ffc237';
      }
      case 'completed': {
        return '#1cc54e';
      }
      case 'complete': {
        return '#1cc54e';
      }
      default: {
        return '';
      }
    }
  }

  // Unsubscribe
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
    this.statusesSubscription.unsubscribe();
  }

  // Render Data Table
  renderTable() {
    // Destroy the table if already initialized
    if (this.dtInitialized) {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
      });
    }

    // Re-render table
    setTimeout(function() {
      this.dtTrigger.next();
    }.bind(this));

    // this.dtElement.dtOptions.search('pending').draw();
  }

  onSearchChange(searchVal: string) {
    console.log(searchVal);

    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      console.log('dtInstance');
      console.log(dtInstance);
      dtInstance.search(searchVal).draw();
    });

    let dataTable = $('table');
    console.log('dt');
    console.log(dataTable);

  }

}
