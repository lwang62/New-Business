import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { NewBusinessStatus } from '@models/new-business-status';

@Component({
  selector: 'app-details-modal',
  templateUrl: './details-modal.component.html',
  styleUrls: ['./details-modal.component.scss']
})
export class DetailsModalComponent implements OnInit {

  @Input() nbStatus: NewBusinessStatus;
  @Output() close = new EventEmitter();

  selectedService = 'all';

  constructor() { }

  ngOnInit() {}

  closeModal() {
    this.close.emit();
  }

}
