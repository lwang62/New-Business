import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoadingService } from '@app/services/common/loading.service';
import { StatusService } from '@services/data/status.service';

@Component({
  selector: 'app-date-search',
  templateUrl: './date-search.component.html',
  styleUrls: ['./date-search.component.scss']
})
export class DateSearchComponent implements OnInit {
  searchRange = 'today';

  constructor(private statusService: StatusService,
              private loadingService: LoadingService) { }

  ngOnInit() { }

  searchByDate(dateRange: string) {
    if (this.searchRange !== dateRange) {
      // Show loader
      this.loadingService.startLoading();

      // Make http request
      this.statusService.searchByDate(dateRange);

      this.searchRange = dateRange;
    }
  }

}
