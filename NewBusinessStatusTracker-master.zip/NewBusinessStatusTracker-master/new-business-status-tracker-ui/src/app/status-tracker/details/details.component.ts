import { Component, OnInit, ViewChild } from '@angular/core';
import { DisplayTypeComponent } from '@statusTracker/display-type/display-type.component';
import { NewBusinessStatus } from '@models/new-business-status';
import { LoadingService } from '@services/common/loading.service';
import { StatusService } from '@services/data/status.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  nbStatuses: NewBusinessStatus[];
  selectedNbStatus: NewBusinessStatus;

  @ViewChild(DisplayTypeComponent) displayTypeComponent: DisplayTypeComponent;

  constructor(private loadingService: LoadingService,
              private statusService: StatusService) { }

  ngOnInit() {
    this.loadingService.startLoading();

    // Search by today - default
    this.statusService.searchByDate('today');
  }
}
