import { Component, OnInit, Input } from '@angular/core';
import { Service } from '@models/service';

@Component({
  selector: 'app-service-details',
  templateUrl: './service-details.component.html',
  styleUrls: ['./service-details.component.scss']
})
export class ServiceDetailsComponent implements OnInit {

  @Input() service: Service;
  @Input() serviceName: string;

  constructor() { }

  ngOnInit() {
  }

}
