export interface Service {
  status?: string;
  request?: string;
  error?: string;
  createdTimeStamp?: Date;
  updatedTimeStamp?: Date;
  createdBy?: string;
  updatedBy?: string;
}
