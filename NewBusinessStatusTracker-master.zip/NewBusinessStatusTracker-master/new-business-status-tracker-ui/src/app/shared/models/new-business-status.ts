import { Request } from './request';
import { Service } from './service';

export interface NewBusinessStatus {
  id: string;
  category: string;
  contractNo: string;
  createdBy: string;
  createdDate: Date;
  modifiedBy: string;
  modifiedDate: Date;
  userId: string;
  distributionId: string;
  status: string;
  request: Request;

  awd: Service;
  lexus: Service;
  mdm: Service;
  nba: Service;
  oaa: Service;
  paris: Service;
  srs: Service;
}
