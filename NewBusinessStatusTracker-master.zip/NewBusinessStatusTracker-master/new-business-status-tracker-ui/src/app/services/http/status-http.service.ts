import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NewBusinessStatus } from '@models/new-business-status';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class StatusHttpService {
  baseUrl = environment.baseApiUrl;

  constructor(private http: HttpClient) { }

  // Get all Statuses
  getAllNewBusinessStatuses() {
    return this.http.post<NewBusinessStatus[]>(`${this.baseUrl}/status`, httpOptions);
  }

  // Get Statuses from today
  getNewBusinessStatusesFromToday() {
    return this.http.post<NewBusinessStatus[]>(`${this.baseUrl}/status/today`, httpOptions);
  }

  // Get Statuses from this week
  getNewBusinessStatusesFromThisWeek() {
    return this.http.post<NewBusinessStatus[]>(`${this.baseUrl}/status/week`, httpOptions);
  }

  // Get Statuses from this month
  getNewBusinessStatusesFromThisMonth() {
    return this.http.post<NewBusinessStatus[]>(`${this.baseUrl}/status/month`, httpOptions);
  }
}
