import { Injectable } from '@angular/core';
import { StatusHttpService } from '../http/status-http.service';
import { LoadingService } from '../common/loading.service';
import { NewBusinessStatus } from '@models/new-business-status';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StatusService {
  nbStatusesSubject = new BehaviorSubject<NewBusinessStatus[]>(null);
  nbStatuses$ = this.nbStatusesSubject.asObservable();

  // Observer
  nbStatusObserver = {
    next: (statuses: NewBusinessStatus[]) => {
      // emit statuses behavior subject
      this.nbStatusesSubject.next(statuses);
    },
    error: err => {
      console.log(err);
      this.loadingService.stopLoading();
    },
    complete: () => console.log('Request completed'),
  };

  constructor(private statusHttpService: StatusHttpService,
              private loadingService: LoadingService) { }

  searchByDate(dateRange: string) {
    // Make http request
    switch (dateRange) {
      case 'week': {
        this.statusHttpService.getNewBusinessStatusesFromThisWeek().subscribe(this.nbStatusObserver);
        break;
      }
      case 'month': {
        this.statusHttpService.getNewBusinessStatusesFromThisMonth().subscribe(this.nbStatusObserver);
        break;
      }
      default: {
        this.statusHttpService.getNewBusinessStatusesFromToday().subscribe(this.nbStatusObserver);
        break;
      }
    }
  }
}
