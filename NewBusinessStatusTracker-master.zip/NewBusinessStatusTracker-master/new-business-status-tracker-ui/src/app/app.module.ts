import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DataTablesModule } from 'angular-datatables';
import { AppRoutingModule } from '@app/app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from '@app/app.component';
import { HttpErrorInterceptor } from '@services/interceptor/http-error-interceptor';
import { LoaderComponent } from './shared/loader/loader.component';
import { LoadingService } from './services/common/loading.service';
import { HeaderComponent } from './shared/layout/header/header.component';
import { DetailsComponent } from '@statusTracker/details/details.component';
import { DetailsModalComponent } from '@statusTracker/modal/details-modal.component';
import { DateSearchComponent } from '@statusTracker/date-search/date-search.component';
import { ServiceDetailsComponent } from '@statusTracker/service-details/service-details.component';
import { DisplayTypeComponent } from '@statusTracker/display-type/display-type.component';
import { DetailsChartComponent } from '@statusTracker/details-chart/details-chart.component';
import { ChartsModule } from 'ng2-charts';
import { PageNotFoundComponent } from './shared/error/page-not-found/page-not-found.component';
import { DataTableComponent } from '@statusTracker/data-table/data-table.component';
import { OverallStatusChartComponent } from '@statusTracker/details-chart/overall-status-chart/overall-status-chart.component';
import { StatusHttpService } from '@services/http/status-http.service';
import { StatusService } from '@services/data/status.service';
import { ServiceChartComponent } from '@statusTracker/details-chart/service-chart/service-chart.component';

@NgModule({
  declarations: [
    AppComponent,
    LoaderComponent,
    DetailsModalComponent,
    DateSearchComponent,
    HeaderComponent,
    DetailsComponent,
    ServiceDetailsComponent,
    DisplayTypeComponent,
    DetailsChartComponent,
    PageNotFoundComponent,
    DataTableComponent,
    OverallStatusChartComponent,
    ServiceChartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    DataTablesModule,
    ChartsModule,
    BrowserAnimationsModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
    StatusService,
    StatusHttpService,
    LoadingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
