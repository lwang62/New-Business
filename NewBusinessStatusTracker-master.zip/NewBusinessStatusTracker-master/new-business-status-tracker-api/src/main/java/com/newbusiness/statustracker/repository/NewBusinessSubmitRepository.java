package com.newbusiness.statustracker.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.newbusiness.statustracker.model.NewBusinessStatus;

public interface NewBusinessSubmitRepository extends MongoRepository<NewBusinessStatus, String> {

}
