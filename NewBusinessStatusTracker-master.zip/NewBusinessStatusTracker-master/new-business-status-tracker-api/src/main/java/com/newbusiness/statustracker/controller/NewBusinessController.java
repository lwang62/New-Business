package com.newbusiness.statustracker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.newbusiness.statustracker.model.NewBusinessStatus;
import com.newbusiness.statustracker.repository.NewBusinessSubmitRepository;
import com.newbusiness.statustracker.service.NewBusinessService;

@RestController
@RequestMapping("/status")
public class NewBusinessController {
	
	@Autowired
	private NewBusinessService newBusinessService;

	@PostMapping
	public List<NewBusinessStatus> getAllNewBusiness() {
		return newBusinessService.findAll();
	}
	
	@GetMapping
	public List<NewBusinessStatus> getAllNewBusinessGet() {
		return newBusinessService.findAll();
	}
	
	@PostMapping("/today")
	public List<NewBusinessStatus> getNewBusinessFromToday() {
		return newBusinessService.getContractsFromToday();
	}
	
	@PostMapping("/week")
	public List<NewBusinessStatus> getNewBusinessFromThisWeek() {
		return newBusinessService.getContractsFromThisWeek();
	}
	
	@PostMapping("/month")
	public List<NewBusinessStatus> getNewBusinessFromThisMonth() {
		return newBusinessService.getContractsFromThisMonth();
	}
}
