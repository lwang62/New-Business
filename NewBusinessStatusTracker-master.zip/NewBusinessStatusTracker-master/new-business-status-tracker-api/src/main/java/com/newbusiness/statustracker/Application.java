package com.newbusiness.statustracker;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.newbusiness.statustracker.model.NewBusinessStatus;
import com.newbusiness.statustracker.model.Request;
import com.newbusiness.statustracker.model.Service;
import com.newbusiness.statustracker.repository.NewBusinessSubmitRepository;

@SpringBootApplication
public class Application implements CommandLineRunner {
	
	Long firstDay, lastDay;

	String userNames[] = new String[] { "sody15","jakeMha22","aleshost","burease","divisionpup","roxGiggly",
			"skillfulMo","hazancent","kiddocial","notessiontr","bagoslimag","holboam","lefollog","parkedeedy",
			"superlive","vartergy","casualogan","gurlynnel","prestiger","scoobygger","strayforks","nathbuddy",
			"steveWonder","tenblog","candlem","finestektr","medialuc","relybad"};
	
	String statuses[] = new String[] { "complete","pending","failed" };
	String errors[] = new String[] {"Failed because system was down"};

	@Autowired
	private NewBusinessSubmitRepository nbRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args); 
	}
	
	private Date addRandomSeconds(Calendar cal) {
		cal.add(Calendar.HOUR_OF_DAY, 1);
		
		int delay = Math.toIntExact(new Random().nextInt(30) + 1);  	
		cal.add(Calendar.SECOND, delay);
		return cal.getTime();
	}
	
	private Calendar getRandomDate() {
        long newTime = (long)(this.firstDay + Math.random()*(this.lastDay - this.firstDay));
        Calendar randCal = Calendar.getInstance();
        randCal.setTimeInMillis(newTime);
        
        System.out.println("Random Date = " + randCal.getTime());
        return randCal;
	}
	
	private String getRandomStatus() {
		double d = Math.random();
		if (d < 0.93) {
			return "completed";
		} else if (d < 0.99) {
			return "pending";
		} else {
			return "failed";
		}
	}
	
	private NewBusinessStatus getRandomNewBusinessStatus() {
		String randUserName = this.userNames[Math.toIntExact(new Random().nextInt(this.userNames.length))];
		
		Calendar randDate = getRandomDate();
		String overallStatus = "completed";
		
		String failedMessage = "";
		
		String status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
		Service awd = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
		
		failedMessage = "";
		
		status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service lexus = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        failedMessage = "";
        
        status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service mdm = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        failedMessage = "";
        
        status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service nba = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        failedMessage = "";
        
        status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service oaa = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        failedMessage = "";
        
        status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service paris = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        failedMessage = "";
        
        status = getRandomStatus();
		if (status.equalsIgnoreCase("failed")) {
			overallStatus = "failed";
			failedMessage = "Failed because system was down";
		} else if (!overallStatus.equalsIgnoreCase("failed") && status.equalsIgnoreCase("pending")) {
			overallStatus = "pending";
		}
        Service srs = new Service(status,"request",failedMessage,addRandomSeconds(randDate),addRandomSeconds(randDate),randUserName,randUserName);
        
        int low = 600000000;
        int high = 999999999;
        int randContractNo = Math.toIntExact(new Random().nextInt(high - low) + low);
        
        NewBusinessStatus nbStatus = new NewBusinessStatus("category",Integer.toString(randContractNo),randUserName,
        		addRandomSeconds(randDate),randUserName,addRandomSeconds(randDate),randUserName,"R12231",overallStatus,
        		new Request(),awd,lexus,mdm,nba,oaa,paris,srs);
		
		return nbStatus;
	}
	
	@Override
	public void run(String... args) throws Exception {
	    
	    // Initialize calendar
		Calendar firstDay= Calendar.getInstance();
		firstDay.setTime(new Date());
	    firstDay.set(Calendar.HOUR_OF_DAY, 0);  
	    firstDay.set(Calendar.MINUTE, 0);  
	    firstDay.set(Calendar.SECOND, 0);  
	    firstDay.set(Calendar.MILLISECOND, 0);
	    firstDay.add(Calendar.DAY_OF_WEEK, -30);
//	    firstDayOfMonth.set(Calendar.DAY_OF_MONTH, 1);
 	    System.out.println("First day of month - " + firstDay.getTime());
 	    this.firstDay = firstDay.getTimeInMillis();


		Calendar lastDayCal = Calendar.getInstance();
		lastDayCal.setTime(new Date());
		lastDayCal.set(Calendar.HOUR_OF_DAY, 0);  
		lastDayCal.set(Calendar.MINUTE, 0);  
		lastDayCal.set(Calendar.SECOND, 0);  
		lastDayCal.set(Calendar.MILLISECOND, 0);
		lastDayCal.add(Calendar.HOUR_OF_DAY, 10);
//		lastDayCal.set(Calendar.HOUR_OF_DAY, 23);  
// 	   	lastDayCal.set(Calendar.MINUTE, 59);  
// 	   	lastDayCal.set(Calendar.SECOND, 59); 
	    System.out.println("Last day - " + lastDayCal.getTime());
	    this.lastDay = lastDayCal.getTimeInMillis();
		
		nbRepository.deleteAll();
		
		for (int x = 0; x < 200; x++) {
			nbRepository.save(getRandomNewBusinessStatus());
		}
		
	}

}
