package com.newbusiness.statustracker.model;

import java.util.Date;

import lombok.Data;

@Data
public class Request {
	private String action;
	private String agentBrokerLst;
	private String allocations;
	private String annualizeCommision;
	private String appContractNo;
	private String application;
	private Date applicationDt;
	private String appMode;
	private String binaryToken;
	private String cashWithApp;
	private String changeRecordSecurity;
	private String clientProfile;
	private String contractNumber;
	private String decFreeform;
	private String decFreeformText;
	private String decRecordSecurity;
	private String decSuppressLetter;
	private Date eisDate;
	private String eisTime;
	private String environment;
	private String gwblInd;
	private String issueData;
	private boolean larsApproval;
	private String larsSystemCode;
	private String lastTrans;
	private String newBusinessAgentData;
	private String newBusinessData;
	private String oldAppNumber;
	private String onlindInd;
	private String planInvestMentOptions;
	private String planVO;
	private String replacements;
	private String semesterAllocationProgram;
	private boolean sioInd;
	private String source;
	private String sourceName;
	private String specificCommision;
	private String srsStatus;
	private String stateOfDelivery;
	private String userId;
}
