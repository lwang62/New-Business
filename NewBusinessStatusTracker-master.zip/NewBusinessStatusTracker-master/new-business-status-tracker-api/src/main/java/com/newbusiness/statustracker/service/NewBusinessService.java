package com.newbusiness.statustracker.service;

import java.util.List;

import com.newbusiness.statustracker.model.NewBusinessStatus;

public interface NewBusinessService {
	List<NewBusinessStatus> findAll();
	List<NewBusinessStatus> getContractsFromToday();
	List<NewBusinessStatus> getContractsFromThisWeek();
	List<NewBusinessStatus> getContractsFromThisMonth();
}
