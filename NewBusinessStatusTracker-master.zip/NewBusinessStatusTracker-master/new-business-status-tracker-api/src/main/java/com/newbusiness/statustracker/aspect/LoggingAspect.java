package com.newbusiness.statustracker.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.newbusiness.statustracker.model.NewBusinessStatus;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
public class LoggingAspect {
	
	@Before("execution(* org.springframework.data.repository.*.*(..)) || "
			+ "execution(* com.newbusiness.statustracker.repository.*.*(..))")
	public void beforeRepository(JoinPoint theJoinPoint) {
		log.info("=====>>> Before " + theJoinPoint.getSignature().toShortString());
		
		// Get args
		Object[] args = theJoinPoint.getArgs();
		
		String paramString = "";
		for (Object arg : args) {
			if (arg instanceof String) {
				paramString += arg.toString();
			}
			if (arg instanceof NewBusinessStatus) {
				NewBusinessStatus nb = (NewBusinessStatus) arg;
				paramString += nb.toString();
			}
		}
		// Loop thru parameters
		if (args != null && args.length > 0) {
			if (args.length == 1) {
				log.info("Parameter- " + paramString);
			} else {
				log.info("Parameters- " + paramString);
			}
		}
		
	}
	
	@AfterReturning(
			pointcut="execution(* org.springframework.data.repository.*.*(..)) || "
					+ "execution(* com.newbusiness.statustracker.repository.*.*(..)) ||"
					+ "execution(* org.springframework.data.mongodb.core.*.*(..))",
			returning="result")
	public void afterReturningRepository(JoinPoint theJoinPoint, List<Object> result) {

		log.info("=====>>> After " + theJoinPoint.getSignature().toShortString());
		
		// print out the results of the method call
		log.info("=====>>> Result is: " + result);
	
	}
	
}
