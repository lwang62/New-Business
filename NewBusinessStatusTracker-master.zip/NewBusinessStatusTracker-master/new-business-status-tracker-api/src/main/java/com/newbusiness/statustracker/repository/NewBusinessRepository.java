package com.newbusiness.statustracker.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.newbusiness.statustracker.model.NewBusinessStatus;

@Repository
public class NewBusinessRepository {

	@Autowired
    private MongoTemplate mongoTemplate;
	
	public List<NewBusinessStatus> getContractsByDate(String dateRange) {
		ZonedDateTime zonedDt = ZonedDateTime.of(LocalDate.now(), LocalTime.MIDNIGHT, ZoneId.systemDefault());
		
		if (dateRange.equalsIgnoreCase("week")) {
			zonedDt = zonedDt.minusDays(7);
		} else if (dateRange.equalsIgnoreCase("month")) {
//			zonedDt = zonedDt.withDayOfMonth(1);
			zonedDt = zonedDt.minusDays(30);
		}
		
		System.out.println(Date.from(zonedDt.toInstant()));
		
		Query query = new Query(Criteria.where("createdDate").gte(Date.from(zonedDt.toInstant())))
        		.with(new Sort(Sort.Direction.DESC, "createdDate"));
        return mongoTemplate.find(query, NewBusinessStatus.class);
	}
	
}
