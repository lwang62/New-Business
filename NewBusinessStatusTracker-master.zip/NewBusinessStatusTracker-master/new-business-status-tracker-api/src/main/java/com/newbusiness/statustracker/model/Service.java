package com.newbusiness.statustracker.model;

import java.util.Date;

import lombok.Data;

@Data
public class Service {	
	String status;
	String request;
	String error;
	Date createdTimeStamp;
	Date updatedTimeStamp;
	String createdBy;
	String updatedBy;
	
	public Service() {}

	public Service(String status, String request, String error, Date createdTimeStamp, Date updatedTimeStamp,
			String createdBy, String updatedBy) {
		this.status = status;
		this.request = request;
		this.error = error;
		this.createdTimeStamp = createdTimeStamp;
		this.updatedTimeStamp = updatedTimeStamp;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}
}
