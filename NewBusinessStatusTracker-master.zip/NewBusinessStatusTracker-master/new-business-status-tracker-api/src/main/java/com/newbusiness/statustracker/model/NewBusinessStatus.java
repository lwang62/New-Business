package com.newbusiness.statustracker.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection="nBStatusTracker")
@Data
public class NewBusinessStatus {
	@Id
    private String id;

	private String category;
	private String contractNo;
	private String createdBy;
	private Date createdDate;
	private String modifiedBy;
	private Date modifiedDate;
	private String userId;
	private String distributionId;
	private String status;
	private Request request;

    private Service awd = new Service();
    private Service lexus = new Service();
    private Service mdm = new Service();
    private Service nba = new Service();
    private Service oaa = new Service();
    private Service paris = new Service();
    private Service srs = new Service();
    
	public NewBusinessStatus(String category, String contractNo, String createdBy, Date createdDate,
			String modifiedBy, Date modifiedDate, String userId, String distributionId, String status, Request request,
			Service awd, Service lexus, Service mdm, Service nba, Service oaa, Service paris, Service srs) {
		this.category = category;
		this.contractNo = contractNo;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
		this.userId = userId;
		this.distributionId = distributionId;
		this.status = status;
		this.request = request;
		this.awd = awd;
		this.lexus = lexus;
		this.mdm = mdm;
		this.nba = nba;
		this.oaa = oaa;
		this.paris = paris;
		this.srs = srs;
	}	
    
}
