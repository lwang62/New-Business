package com.newbusiness.statustracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.newbusiness.statustracker.model.NewBusinessStatus;
import com.newbusiness.statustracker.repository.NewBusinessRepository;
import com.newbusiness.statustracker.repository.NewBusinessSubmitRepository;

@Service
public class NewBusinessServiceImpl implements NewBusinessService {
	
	@Autowired
	private NewBusinessRepository newBusinessRepository;
	
	@Autowired
	private NewBusinessSubmitRepository newBusinessMongoRepo;

	@Override
	@Transactional
	public List<NewBusinessStatus> getContractsFromToday() {
		return newBusinessRepository.getContractsByDate("today");
	}

	@Override
	public List<NewBusinessStatus> getContractsFromThisWeek() {
		return newBusinessRepository.getContractsByDate("week");
	}

	@Override
	public List<NewBusinessStatus> getContractsFromThisMonth() {
		return newBusinessRepository.getContractsByDate("month");
	}

	@Override
	public List<NewBusinessStatus> findAll() {
		return newBusinessMongoRepo.findAll();
	}

}
